#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include "queue.h"

void Init_Queue(String_Queue *queue) {
	queue->head = NULL;
	queue->tail = NULL;
	queue->size = 0;
}

void Free_Queue(String_Queue *queue) {

	if (!Empty_Queue(queue)) {
		int i;
		String_Node *node = queue->head, *next;

		for (i = 0; i < queue->size; i++) {
			next = node->right;
			free(node);
			node = next;
		}
	}
	queue->head = NULL;
	queue->tail = NULL;
	queue->size = 0;
}

void Print_Node(String_Queue *queue) {
		if (Empty_Queue(queue))	return;
		
		int i;
		String_Node *node = queue->head;
	
		for (i = 0; i < queue->size; i++) {
			//printf("left : %x, right : %x, context : %s\n", node->left, node->right, node->context);
			printf(" %s |", node->context);
			node = node->right;
		}
		printf("\n");
}

int Empty_Queue(String_Queue *queue) {
	if (queue != NULL && queue->size > 0)
		return 0;
	else	return -1;
}

String_Node *Create_Node(char *str) {
	String_Node *node = (String_Node *)malloc(sizeof(String_Node));
	int len;

	if (node == NULL)
		return node;

	len = strlen(str);
	node->context = (char *)malloc(sizeof(char)*(len + 1));
	strncpy(node->context, str, len + 1);

	node->left = NULL;
	node->right = NULL;
	return node;
}

int Enqueue(String_Queue *queue, char *str) {

	String_Node *node = Create_Node(str);

	if (node == NULL) {
		printf("failed create new node\n");
		return -1;
	}

	if (queue->head == NULL && queue->tail == NULL) {
		queue->head = node;
		queue->tail = node;
	}
	else {
		String_Node *end = queue->tail;
		node->left = end;
		end->right = node;
		queue->tail = node;
	}
	queue->size++;
	//printf("head : %x, tail : %x\n", queue->head, queue->tail);
	//printf("Enqueue %s\n", str);
	return 0;
}

char *Dequeue(String_Queue *queue) {
	char *str = NULL;
	int len;

	if (!Empty_Queue(queue)) {
		String_Node *tmp;
		String_Node *first = queue->head;
		queue->head = first->right;
		tmp = first->right;
		if (tmp != NULL)
			tmp->left = NULL;

		len = strlen(first->context);
		str = (char *)malloc(sizeof(char)*(len + 1));
		strncpy(str, first->context, len + 1);

		free(first);
		//printf("head : %x, tail : %x\n", queue->head, queue->tail);
		//printf("Dequeue %s\n", str);
		queue->size--;

		return str;
	}
	else {
		printf("queue is empty\n");
		return str;
	}
}

char *Pop(String_Queue *queue) {
	char *str = NULL;
	int len;

	if (!Empty_Queue(queue)) {
		String_Node *tmp;
		String_Node *end = queue->tail;
		queue->tail = end->left;
		tmp = end->left;
		if (tmp != NULL)
			tmp->right = NULL;

		len = strlen(end->context);
		str = (char *)malloc(sizeof(char)*(len + 1));
		strncpy(str, end->context, len + 1);

		free(end);
		//printf("head : %x, tail : %x\n", queue->head, queue->tail);
		//printf("Pop %s\n", str);
		queue->size--;

		return str;
	}
	else {
		printf("queue is empty\n");
		return str;
	}
}

