#ifndef QUEUE_H
#define QUEUE_H

typedef struct _node {
	char *context;
	struct _node *left, *right;
}String_Node;

typedef struct _queue{
	String_Node *head, *tail;
	int size;
}String_Queue;

String_Node *Create_Node(char *str);
void Print_Node(String_Queue *queue);
void Init_Queue(String_Queue *queue);
void Free_Queue(String_Queue *queue);
int Empty_Queue(String_Queue *queue);
int Enqueue(String_Queue *queue, char *str);
char *Dequeue(String_Queue *queue);
char *Pop(String_Queue *queue);

#endif
