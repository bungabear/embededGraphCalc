#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include "equation.h"


int main() {
	printf("equation : y=sin(x^2-6x-16)/x\n");

	String_Queue *EQ = (String_Queue *)malloc(sizeof(String_Queue));
	String_Queue *IQ;
	int res;

	Init_Queue(EQ);

	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, "sin");
	if (res < 0) return -1;
	res = Enqueue(EQ, "(");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "^");
	if (res < 0) return -1;
	res = Enqueue(EQ, "2");
	if (res < 0) return -1;
	res = Enqueue(EQ, "-");
	if (res < 0) return -1;
	res = Enqueue(EQ, "6");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "-");
	if (res < 0) return -1;
	res = Enqueue(EQ, "1");
	if (res < 0) return -1;
	res = Enqueue(EQ, "6");
	if (res < 0) return -1;
	res = Enqueue(EQ, ")");
	if (res < 0) return -1;
	res = Enqueue(EQ, "/");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;

	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;

	Print_Node(IQ);
	
	Free_Queue(EQ);
	Free_Queue(IQ);

	/*---------------------------------------------------------------------------------*/

	printf("\n equation : y=e(x^2+(16x-10.5)\n");

	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, "e");
	if (res < 0) return -1;
	res = Enqueue(EQ, "(");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "^");
	if (res < 0) return -1;
	res = Enqueue(EQ, "2");
	if (res < 0) return -1;
	res = Enqueue(EQ, "+");
	if (res < 0) return -1;
	res = Enqueue(EQ, "(");
	if (res < 0) return -1;
	res = Enqueue(EQ, "1");
	if (res < 0) return -1;
	res = Enqueue(EQ, "6");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "-");
	if (res < 0) return -1;
	res = Enqueue(EQ, "1");
	if (res < 0) return -1;
	res = Enqueue(EQ, "0");
	if (res < 0) return -1;
	res = Enqueue(EQ, ".");
	if (res < 0) return -1;
	res = Enqueue(EQ, "5");
	if (res < 0) return -1;
	res = Enqueue(EQ, ")");

	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;
		
	Print_Node(IQ);

	Free_Queue(EQ);
	Free_Queue(IQ);

	/*---------------------------------------------------------------------------------*/

	printf("\n equation : y=log(8x^2(16x-128)e/x+100.15\n");

	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, "log");
	if (res < 0) return -1;
	res = Enqueue(EQ, "(");
	if (res < 0) return -1;
	res = Enqueue(EQ, "8");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "^");
	if (res < 0) return -1;
	res = Enqueue(EQ, "2");
	if (res < 0) return -1;
	res = Enqueue(EQ, "(");
	if (res < 0) return -1;
	res = Enqueue(EQ, "1");
	if (res < 0) return -1;
	res = Enqueue(EQ, "6");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "-");
	if (res < 0) return -1;
	res = Enqueue(EQ, "1");
	if (res < 0) return -1;
	res = Enqueue(EQ, "2");
	if (res < 0) return -1;
	res = Enqueue(EQ, "8");
	if (res < 0) return -1;
	res = Enqueue(EQ, ")");
	if (res < 0) return -1;
	res = Enqueue(EQ, "e");
	if (res < 0) return -1;
	res = Enqueue(EQ, "/");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "+");
	if (res < 0) return -1;
	res = Enqueue(EQ, "1");
	if (res < 0) return -1;
	res = Enqueue(EQ, "0");
	if (res < 0) return -1;
	res = Enqueue(EQ, "0");
	if (res < 0) return -1;
	res = Enqueue(EQ, ".");
	if (res < 0) return -1;
	res = Enqueue(EQ, "1");
	if (res < 0) return -1;
	res = Enqueue(EQ, "5");
	if (res < 0) return -1;

	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;

	Print_Node(IQ);

	Free_Queue(EQ);
	Free_Queue(IQ);

	/*---------------------------------------------------------------------------------*/

	printf("\n equation : y=log(sin(Px)2x-64e)\n");

	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, "log");
	if (res < 0) return -1;
	res = Enqueue(EQ, "(");
	if (res < 0) return -1;
	res = Enqueue(EQ, "sin");
	if (res < 0) return -1;
	res = Enqueue(EQ, "(");
	if (res < 0) return -1;
	res = Enqueue(EQ, "P");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, ")");
	if (res < 0) return -1;
	res = Enqueue(EQ, "2");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "-");
	if (res < 0) return -1;
	res = Enqueue(EQ, "6");
	if (res < 0) return -1;
	res = Enqueue(EQ, "4");
	if (res < 0) return -1;
	res = Enqueue(EQ, "e");
	if (res < 0) return -1;
	res = Enqueue(EQ, ")");

	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;

	Print_Node(IQ);

	Free_Queue(EQ);
	Free_Queue(IQ);

	/*---------------------------------------------------------------------------------*/

	/*printf("\n equation : y=sin(x+2))\n");
	
	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, "sin");
	if (res < 0) return -1;
	res = Enqueue(EQ, "(");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "+");
	if (res < 0) return -1;
	res = Enqueue(EQ, "2");
	if (res < 0) return -1;
	res = Enqueue(EQ, ")");
	if (res < 0) return -1;
	res = Enqueue(EQ, ")");
	if (res < 0) return -1;

	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;

	Print_Node(IQ);

	Free_Queue(EQ);
	Free_Queue(IQ);*/

	/*---------------------------------------------------------------------------------*/

	/*printf("\n equation : y=+x\n");

	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, "+");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;

	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;

	Print_Node(IQ);

	Free_Queue(EQ);
	Free_Queue(IQ);*/

	/*---------------------------------------------------------------------------------*/

	/*printf("\n equation : y=x.\n");

	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, ".");
	if (res < 0) return -1;

	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;

	Print_Node(IQ);

	Free_Queue(EQ);
	Free_Queue(IQ);*/

	/*---------------------------------------------------------------------------------*/

	/*printf("\n equation : y=x+*\n");

	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "+");
	if (res < 0) return -1;
	res = Enqueue(EQ, "*");
	if (res < 0) return -1;

	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;

	Print_Node(IQ);

	Free_Queue(EQ);
	Free_Queue(IQ);*/

	/*---------------------------------------------------------------------------------*/

	/*printf("\n equation : y=(*x\n");

	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, "(");
	if (res < 0) return -1;
	res = Enqueue(EQ, "*");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;

	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;

	Print_Node(IQ);

	Free_Queue(EQ);
	Free_Queue(IQ);*/

	/*---------------------------------------------------------------------------------*/

	/*printf("\n equation : y=)\n");

	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, ")");
	if (res < 0) return -1;


	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;

	Print_Node(IQ);

	Free_Queue(EQ);
	Free_Queue(IQ);*/

	/*---------------------------------------------------------------------------------*/

	printf("\n equation : y=sin(x+P)e./x\n");

	res = Enqueue(EQ, "y=");
	if (res < 0) return -1;
	res = Enqueue(EQ, "sin");
	if (res < 0) return -1;
	res = Enqueue(EQ, "(");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;
	res = Enqueue(EQ, "+");
	if (res < 0) return -1;
	res = Enqueue(EQ, "P");
	if (res < 0) return -1;
	res = Enqueue(EQ, "e");
	if (res < 0) return -1;
	res = Enqueue(EQ, ".");
	if (res < 0) return -1;
	res = Enqueue(EQ, "/");
	if (res < 0) return -1;
	res = Enqueue(EQ, "x");
	if (res < 0) return -1;

	IQ = Reguler_equation(EQ);
	if (IQ == NULL) return -1;

	Print_Node(IQ);

	Free_Queue(EQ);
	Free_Queue(IQ);

	return 0;
}