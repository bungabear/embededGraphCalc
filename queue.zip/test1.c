//#include <stdio.h>
//#include <string.h>
//#include <stdlib.h>
//#include <malloc.h>
//#include "queue.h"
//
//int main() {
//	String_Queue *tQ = (String_Queue *)malloc(sizeof(String_Queue));
//	Init_Queue(tQ);
//	char *str;
//	int res;
//	printf("test1 : enqueue / dequeue \n");
//	printf("\n\n");
//
//	res = Enqueue(tQ, "abc");
//	if (res < 0) return -1;
//	res = Enqueue(tQ, "def");
//	if (res < 0) return -1;
//	res = Enqueue(tQ, "ghi");
//	if (res < 0) return -1;
//	res = Enqueue(tQ, "jkl");
//	if (res < 0) return -1;
//	res = Enqueue(tQ, "mno");
//	if (res < 0) return -1;
//	res = Enqueue(tQ, "pqr");
//	if (res < 0) return -1;
//
//	printf("\n\n");
//
//	/*str = Dequeue(tQ);
//	if (str == NULL) return -1;
//	printf("Dequeue %s\n", str);
//	str = Dequeue(tQ);
//	if (str == NULL) return -1;
//	printf("Dequeue %s\n", str);
//	str = Dequeue(tQ);
//	if (str == NULL) return -1;
//	printf("Dequeue %s\n", str);
//	str = Dequeue(tQ);
//	if (str == NULL) return -1;
//	printf("Dequeue %s\n", str);
//	str = Dequeue(tQ);
//	if (str == NULL) return -1;
//	printf("Dequeue %s\n", str);*/
//
//	/*str = Pop(tQ);
//	if (str == NULL) return -1;
//	printf("Pop %s\n", str);
//	str = Pop(tQ);
//	if (str == NULL) return -1;
//	printf("Pop %s\n", str);
//	str = Pop(tQ);
//	if (str == NULL) return -1;
//	printf("Pop %s\n", str);
//	str = Pop(tQ);
//	if (str == NULL) return -1;
//	printf("Pop %s\n", str);
//	str = Pop(tQ);
//	if (str == NULL) return -1;
//	printf("Pop %s\n", str);*/
//
//	str = Pop(tQ);
//	if (str == NULL) return -1;
//	printf("Pop %s\n", str);
//	str = Dequeue(tQ);
//	if (str == NULL) return -1;
//	printf("Dequeue %s\n", str); 
//	str = Pop(tQ);
//	if (str == NULL) return -1;
//	printf("Pop %s\n", str);
//	str = Dequeue(tQ);
//	if (str == NULL) return -1;
//	printf("Dequeue %s\n", str);
//	str = Pop(tQ);
//	if (str == NULL) return -1;
//	printf("Pop %s\n", str);
//	str = Dequeue(tQ);
//	if (str == NULL) return -1;
//	printf("Dequeue %s\n", str);
//
//}